import "../../styles/header.css"

const Header = () => {
  return (
    <>
      <div className="main-header">
        <div className="col-2 shift-r-16 logo">OLumsX</div>
      </div>
    </>
  );
};

export default Header;
