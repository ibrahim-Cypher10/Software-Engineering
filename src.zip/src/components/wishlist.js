import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

const Wishlist = () => {
  return <>Wishlist</>;
};

export default Wishlist;